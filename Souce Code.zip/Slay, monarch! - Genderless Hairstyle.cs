﻿using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using Debug = UnityEngine.Debug;
using TMPro;

namespace SlayMonarchGenderlessHair;

[BepInPlugin("org.bepinex.plugins.SlayMonarchGenderlessHair", "Slay, monarch! - Genderless Hair for Chef RPG", "0.85")]
[BepInProcess("Chef RPG.exe")]
public class Plugin : BaseUnityPlugin
{
    internal static new ManualLogSource Logger;

    private void Awake()
    {
        // Plugin startup logic
        Logger = base.Logger;

        Harmony harmony = new Harmony("org.bepinex.plugins.SlayMonarchGenderlessHair");
        harmony.PatchAll();
        Logger.LogInfo("is loaded!");
    }
}

[HarmonyPatch(typeof(HairDatabase),"GetRandomNPCHairList")]
public class p_GetRandomNPCHairList
{
    static bool Prefix(HairDatabase __instance, bool isChild, ref List<HairItem> __result,
    HairItem[] ___hairItems)
    {
        __result = new List<HairItem>();
        Debug.Log("----------------------------------------------------------------------------------------------------------");
        Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. GetRandomNPCHairList patch started.");

        Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Loop started.");
        for (int i = 0; i < ___hairItems.Length; i++)
        {
            var item = ___hairItems[i];

            if (!item.RandomNPCAvailable)
            {
                continue;
            }

            if (isChild && item.IsChild)
            {
                __result.Add(item);
            }
            else if (!isChild && !item.IsChild)
            {
                __result.Add(item);
            }
        }
        Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Loop finished.");
        Debug.Log("----------------------------------------------------------------------------------------------------------");
        return false;
    }
}

[HarmonyPatch(typeof(CharacterCreationUI), "UpdateHair")]
public class p_UpdateHair
{
    static AccessTools.FieldRef<CharacterCreationUI, List<HairItem>> malehairRef = 
    AccessTools.FieldRefAccess<CharacterCreationUI,List<HairItem>>("MaleHairs");
    static AccessTools.FieldRef<CharacterCreationUI, List<HairItem>> femalehairRef = 
    AccessTools.FieldRefAccess<CharacterCreationUI, List<HairItem>>("FemaleHairs");

    static List<HairItem> AllHairs;

    static void Postfix(CharacterCreationUI __instance, TextMeshProUGUI ___HairText, PlayerImageManager ___playerImageManager)
    {
        Debug.Log("----------------------------------------------------------------------------------------------------------");
        Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Character Creation Ui patch started.");

        if (AllHairs == null)
        {
            AllHairs = malehairRef(__instance).Concat(femalehairRef(__instance)).ToList();
            Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. New hairs array created.");
        }


        if (malehairRef(__instance) != femalehairRef(__instance))
        {
            malehairRef(__instance) = AllHairs;
            femalehairRef(__instance) = AllHairs;
            
            Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Male and female hairs arrays changed.");
        }

        Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Initializing search...");
        
        try
        {
            ___HairText.text = LocalizationSystem.GetLocalisedValue("Hair_F_" + ___playerImageManager.HairAnimationManager.CurrentHair.HairName, 3);
            Debug.Log($"[Slay, monarch! - Genderless Hair for Chef RPG] called. Directed to female option: {___HairText.text}");

            if(string.IsNullOrWhiteSpace(___HairText.text))
            {
                Debug.Log($"[Slay, monarch! - Genderless Hair for Chef RPG] called. Female option not found: searching for male....");
                ___HairText.text = LocalizationSystem.GetLocalisedValue("Hair_M_" + ___playerImageManager.HairAnimationManager.CurrentHair.HairName, 3);
                Debug.Log($"[Slay, monarch! - Genderless Hair for Chef RPG] called. Directed to male option: {___HairText.text}");
            }
        }
        catch (Exception e)
        {
                Debug.Log($"[DialogExpanded] Error - hair name couldn't be found: {e.Message}");
        }
        Debug.Log("----------------------------------------------------------------------------------------------------------");
    }
}

[HarmonyPatch(typeof(HairSalon), "UpdateCharacterImage")]
public class p_UpdateCI
{

    static void Postfix(HairSalon __instance, TextMeshProUGUI ___HairNameText, HairItem ___currentHair)
    {
        Debug.Log("----------------------------------------------------------------------------------------------------------");
        Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Update Character Image patch started.");
        if (string.IsNullOrEmpty(___HairNameText.text))
        {
            Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Hair name not found. Initializing fix:");
            try
            {
                ___HairNameText.text = LocalizationSystem.GetLocalisedValue("Hair_F_" + ___currentHair.HairName, 3);
                Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Directed to female option");
            }
            catch
            {
                ___HairNameText.text = LocalizationSystem.GetLocalisedValue("Hair_M_" + ___currentHair.HairName, 3);
                Debug.Log("[Slay, monarch! - Genderless Hair for Chef RPG] called. Directed to male option");
            }
        }
        Debug.Log("----------------------------------------------------------------------------------------------------------");
    }
}